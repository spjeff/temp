﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace CreateTaskForNewAccount
{
    public class NewAccount : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // obtain the tracing service
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // get the execution context from the service provider
            IPluginExecutionContext pluginExecutionContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // check to see if InputParams Collection has all the data passed in the message request.
            if (pluginExecutionContext.InputParameters.Contains("Target") && pluginExecutionContext.InputParameters["Target"] is Entity)
            {
                // get the target entity from the input params
                Entity entity = (Entity)pluginExecutionContext.InputParameters["Target"];

                // obtain org to make web service cal
                IOrganizationServiceFactory organizationServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService organizationService = organizationServiceFactory.CreateOrganizationService(pluginExecutionContext.UserId);

                try
                {
                    // Createatask activity to follow up with the Account in7days from the creation of the account.
                    Entity followup = new Entity("task");
                    followup["subject"] = "Send an email to the new customer.";
                    followup["description"] = "Follow up with the customer.Check if there are issues that need resolution or sales opportunities.";
                    followup["scheduledstart"] = DateTime.Now.AddDays(7);
                    followup["scheduledend"] = DateTime.Now.AddDays(7);
                    followup["category"] = pluginExecutionContext.PrimaryEntityName;

                    // set the regarding of the new task to the newly created Account
                    if (pluginExecutionContext.OutputParameters.Contains("id"))
                    {
                        Guid regardingobjectid = new Guid(pluginExecutionContext.OutputParameters["id"].ToString());
                        string regardingobjectidType = "account";
                        followup["regardingobjectid"] = new EntityReference(regardingobjectidType, regardingobjectid);
                    }

                    // create the task in PowerApps against the newly created Account record.
                    tracingService.Trace("NewAccountPlugin:Creating the task activity.");
                    organizationService.Create(followup);
                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw new InvalidPluginExecutionException("An error has occurred in the NewAccountPlugin:", ex);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("NewAccountPlugin:{0}", ex.ToString());
                }
            }
        }
    }
}
